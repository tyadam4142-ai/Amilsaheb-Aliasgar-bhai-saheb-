Amilsaheb NFC Contact Profile
==============================
Name: Aliasgar bs Najmi
Display: Amilsaheb
Phone / WhatsApp: +1 (240) 731-7462

Files:
- index.html
- style.css
- script.js

The page uses the official Aljamea-tus-Saifiyah image URLs for the campus collage and faded Surat hero background. Internet access is therefore required for those photographs and Google Fonts.

Official source: https://jameasaifiyah.edu/
