(() => {
  "use strict";

  const loader = document.getElementById("loader");
  const toast = document.getElementById("toast");
  const saveButton = document.getElementById("saveContact");

  const hideLoader = () => loader?.classList.add("hide");
  window.addEventListener("load", () => setTimeout(hideLoader, 650));
  setTimeout(hideLoader, 3000);

  let toastTimer;
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2500);
  }

  saveButton?.addEventListener("click", () => {
    const vcard = [
      "BEGIN:VCARD",
      "VERSION:3.0",
      "FN:Aliasgar bs Najmi",
      "N:Najmi;Aliasgar bs;;;",
      "ORG:Amilsaheb",
      "TEL;TYPE=CELL:+12407317462",
      "TEL;TYPE=WHATSAPP:+12407317462",
      "NOTE:Amilsaheb — Aljamea-tus-Saifiyah, Surat",
      "END:VCARD"
    ].join("\r\n");

    try {
      const blob = new Blob([vcard], { type: "text/vcard;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "Aliasgar-bs-Najmi.vcf";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast("Contact card ready to save");
    } catch {
      showToast("Please use the phone number to save the contact");
    }
  });

  // Lightweight atmospheric particles.
  const canvas = document.getElementById("particles");
  const ctx = canvas?.getContext("2d");
  if (canvas && ctx) {
    let particles = [];
    let w = 0, h = 0, dpr = 1;

    function resize() {
      w = window.innerWidth;
      h = window.innerHeight;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      const count = Math.min(48, Math.max(18, Math.floor((w * h) / 26000)));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.16,
        vy: (Math.random() - 0.5) * 0.16,
        r: Math.random() * 1.2 + 0.3,
        a: Math.random() * 0.3 + 0.08
      }));
    }

    function draw() {
      ctx.clearRect(0, 0, w, h);
      for (const p of particles) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;
        if (p.y < -10) p.y = h + 10;
        if (p.y > h + 10) p.y = -10;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(234,213,157,${p.a})`;
        ctx.fill();
      }
      requestAnimationFrame(draw);
    }

    resize();
    window.addEventListener("resize", resize, { passive: true });
    draw();
  }
})();